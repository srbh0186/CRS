import { X, _ } from "../chunks/2.D3x_Usqw.js";
export {
  X as component,
  _ as universal
};
