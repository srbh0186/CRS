import { G, f } from "./mermaid-parser.core.2MwSWu3D.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
