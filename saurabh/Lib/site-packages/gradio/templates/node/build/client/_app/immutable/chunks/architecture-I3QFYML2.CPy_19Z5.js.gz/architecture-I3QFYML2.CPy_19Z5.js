import { A, e } from "./mermaid-parser.core.2MwSWu3D.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
